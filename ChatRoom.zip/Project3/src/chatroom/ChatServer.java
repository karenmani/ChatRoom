package chatroom;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Karen Mani
 */

public class ChatServer extends ChatWindow {
	private ClientHandler handler;
	public ArrayList<ClientHandler> clients = new ArrayList<>();
	

	public ChatServer(){
		super();
		this.setTitle("Chat Server");
		this.setLocation(80,80);

		try {
			// Create a listening service for connections
			// at the designated port number.
			ServerSocket srv = new ServerSocket(2113);

			while (true) {
				// The method accept() blocks until a client connects.
				printMsg("Waiting for a connection");
				Socket socket = srv.accept();

				handler = new ClientHandler(socket);
				clients.add(handler);
				handler.connect(); 
				/*dont know what my error is here but it is not
				 * allowing multiple thread connections
				 */
			}

		} catch (IOException e) {
			System.out.println(e);
		} //error message
	}

	/** This inner class handles communication to/from one client. */
	class ClientHandler implements Runnable {
		public String name="";
		private PrintWriter writer;
		private BufferedReader reader;
		public String clientMsg = "Client connected";
		Socket socket;
		public ClientHandler(Socket socket) {
			try {
				InetAddress serverIP = socket.getInetAddress();
				printMsg("Connection made to " + serverIP);
				writer = new PrintWriter(socket.getOutputStream(), true);
				reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			}
			catch (IOException e){
					printMsg("\nERROR:" + e.getLocalizedMessage() + "\n");
				}
			this.socket=socket;
		}
		public void handleConnection() {
			try {
				while(true) {
					// read a message from the client
					String sr = readMsg();
					String temp=""; //sets temporary string for name
					if((sr.length()>=7)) 
					{
						temp=sr.substring(0, 5);
						if(temp.equals("/name")) {
							name=sr.substring(6);
							clientMsg=(name);
							printMsg("Client's name is now " + name);
							continue;
						}
					}
					/* if the message typed is more than 7 characters, set temp to read the first 6 characters.
					 * if those first 6 character are "/name" then set the name of the client equal to the name
					 * specified in that message and print a confirmation message on server. then keep going. */
					
					sendMsg(sr); //continues with sending and receiving messages
				}
			}
			catch (IOException e){
				printMsg("\nERROR:" + e.getLocalizedMessage() + "\n");
			}
			
			KeyListener listener = new KeyListener()
	        {
	            public void keyPressed(KeyEvent e)
	            {
	                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
	                	try {
							sendMsg(readMsg());
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
	                }
	            }
	            @Override
	            public void keyTyped(KeyEvent e) { }
	            @Override
	            public void keyReleased(KeyEvent e) { }
	        };
		}
		
		public void run() {
			this.handleConnection();
		}
		
		public void connect() {
			Thread thread = new Thread(this); 
			//threading for multiple clients
			thread.start();
		}
		
		/** Receive and display a message 
		 * @return */
		public String readMsg() throws IOException {
			String s = reader.readLine();
			printMsg(s);
			return s;
			//takes input from line and prints it to screen using printMsg method
		}
		/** Send a string */
		public void sendMsg(String s) throws IOException {
				
				for(int i=0; i<clients.size(); i++)
				{
					clients.get(i).writer.println(name + ": " +s);
					System.out.println("Number of clients connected: " + (i+1));
				}
				/* just a verification method to print the number of clients connected
				 * to the console to make sure they were connecting properly when my 
				 * program was being written */
	}
}


public static void main(String args[]) {
		new ChatServer();
	} 
}